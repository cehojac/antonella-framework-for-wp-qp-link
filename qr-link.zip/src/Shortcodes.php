<?php
namespace UYGDDI;

use UYGDDI\Config;

class Shortcodes
{
    public function __construct()
    {
    }

    public static function index()
    {
        $config= new Config;
        $filter=$config->shortcodes;
        // add_shortcode('example', array('Shortcodes','example_function'));
        if ($filter) {
            foreach ($filter as $data) {
                call_user_func_array('add_shortcode', [$data[0],$data[1]]);
            }
        }
    }
    /*
    * shortcode example
    * @info: https://codex.wordpress.org/Shortcode
    * @return string
    */
    public function qrCode($atts)
    {
        extract(shortcode_atts(array(
            'text' => '',
            'size' => '300',
            'margin' => '10',
            'error_correction' => 'high'
         ), $atts));
        $qrCode = new QrCode($atts['text']);
        $qrCode->setSize($atts['size']);
        $qrCode->setMargin($atts['margin']);
        $qrCode->setErrorCorrection($atts['error_correction']);
        return '<img src="' . $qrCode->writeDataUri() . '">';
    }
}
