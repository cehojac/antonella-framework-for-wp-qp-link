<?php
namespace UYGDDI;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
